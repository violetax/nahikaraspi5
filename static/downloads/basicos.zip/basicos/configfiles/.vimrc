set nocompatible

syntax on
filetype plugin indent on

set mouse=

set number

set backspace=indent,eol,start

set ignorecase
set smartcase

set incsearch

set autoindent

set tabstop=4
set shiftwidth=4
set expandtab

set exrc
set secure
