#!/usr/bin/awk -f

# This script splits an input file into multiple output files
# where each new file starts at lines that match the pattern '^//'.

# Define the pattern that marks the beginning of a new file.
BEGIN {
    file_index = 0
    output_file = ""
	SITE = "SITE"
	htempD = "hugo_"  SITE  "_templates"
	htdcD  = htempD  "/default_config"
	htarD  = htempD  "/archetypes"
	htdaD  = htempD  "/data"
	i18nD  = htdaD  "/i18n"
	subarr[0] = htempD
	subarr[1] = htdcD
	subarr[2] = htarD
	subarr[3] = htdaD
	subarr[4] = i18nD
	catcharr[0] = "htempD"
	catcharr[1] = "htdcD"
	catcharr[2] = "htarD"
	catcharr[3] = "htdaD"
	catcharr[4] = "i18n"
	G = 5
	F = 0
}

# If the line matches the pattern, increment the file index and
# open a new output file.
{
    if ($0 ~ /^cat/) {
		fname = $4
		for (i = 0; i < G; i++) {
			if (match(fname,catcharr[i])) {
				gsub(/\$\{.*\}/, subarr[i], fname)
				if (!(fname in filesarr)) {
					filesarr[fname] = 1
					F++
				}
			}
		}
    }
}

# Close the output files when done.
END {
	for (f in filesarr) {
		print f > SITE ".txt"
	}
}
