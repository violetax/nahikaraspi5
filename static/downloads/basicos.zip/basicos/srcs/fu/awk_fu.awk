#!/usr/bin/awk -f

BEGIN {}
(NR == 2) {
	dfile=$4
	printf("\t[[ -f \"%s\" ]] && rm \"%s\"\n", dfile, dfile)
}
{
	print
}
END {}
