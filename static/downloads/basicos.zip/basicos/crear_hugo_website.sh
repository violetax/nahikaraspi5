#!/bin/bash

# SEC PRELIMS
cuseco=$(basename $0)
array_de_funciones_principales=(
	'basico_crear_site'
	'funcion_main'
)	
function confirmar() {
		if [ $# -gt 0 ]; then
			if [ ! -z $1 ] && [ $1 = [Aa] ]; then
				echo -e "\033[38;5;118mAURRERA pues \033[0m "
				return 0
			elif [ ! -z $1 ] && [ $1 = [Ee] ]; then
				echo -e "\033[38;5;9mpues EZ\033[0m"
				return 1
			fi
		fi
		echo -e "\033[38;5;118mAURRERA \033[38;5;193medo \033[38;5;9mEZ \033[38;5;11m???\033[0m"
		while read -r -n 1 -s answer
		do
			if [[ ${answer} = [AaEe] ]]; then
				[[ ${answer} = [Aa] ]] && echo -e "\033[38;5;118mAURRERA pues \033[0m " && retval=0
				[[ ${answer} = [Ee] ]] && echo -e "\033[38;5;9mpues EZ\033[0m" && retval=1
				break
			fi
		done
		return ${retval}
}
# FIN de PRELIMS
# DIRS
DIRECTORIOdeTRABAJO="${PWD}"
# FILES
script_auxiliar="${DIRECTORIOdeTRABAJO}/auxiliar_crear_hugo_website.sh" 
# SEC VARIABLES 1
FUNCION="false" 
# FIN de VARIABLES 1
function informacion() {
	echo -e "\033[38;5;11m★ \033[38;5;155m Versión minimalista para \033[38;5;208m:	\033[0m"
	echo -e "\033[38;5;11m◇  1 \033[38;5;195m#\033[38;5;14m Crea el sitio Hugo \033[38;5;195m\${array_de_valores[\033[38;5;11m0\033[38;5;195m]}"
	echo -e "\033[38;5;11m◇  2 \033[38;5;195m#\033[38;5;14m Instala el \033[38;5;222mtheme \033[38;5;218mhugo-learn \033[38;5;14mcomo submódulo"
	echo -e "\033[38;5;11m◇  3 \033[38;5;195m#\033[38;5;14m Edita \033[38;5;193mconfig.toml \033[38;5;14mcon lo mínimo necesario para que funcione el theme"
	echo -e "\033[38;5;11m◇  4 \033[38;5;195m#\033[38;5;14m Crea una estructura mínima de contenido con una página de inicio y otra de ejemplo"
	echo -e "\033[38;5;11m◇  5 \033[38;5;195m#\033[38;5;14m Lanza el servidor local, \033[38;5;155mif \033[38;5;195mconfirmar"
	if [[ ${#array_de_funciones_principales[@]} -gt 0 ]]; then
		echo -e "\033[38;5;11m★\033[38;5;45m Funciones\033[38;5;218m → "
		for funcion in ${array_de_funciones_principales[@]}
		do
			echo -e " 🔨⚡ \033[38;5;155m${funcion}\033[38;5;218m"
		done | nl
	fi
	echo -e "\033[38;5;218m I job, I job 💕 \033[38;5;228m!!!!"
	return 0
} # FIN de informacion
# SEC GETOPTS
while getopts ":eh" o; do
	case "${o}" in
		e) vim $0 ; exit 0 ;; 
		h) informacion ; exit 0 ;; 
		*) exit 0 ;;
	esac
done
shift $((OPTIND-1))
# FIN de GETOPTS
# SEC VARIABLES 2
array_de_valores=( "$@" )
# FIN de VARIABLES 2
# SECCION FUNCIONES
function select_funcion_FU() {
	select funcion in ${array_de_funciones_principales[@]} "Quit"
	do
		[[ "${funcion}" == "Quit" ]] && break  
		${funcion} ${array_de_valores[@]} 
		break
	done	
} # FIN función select_funcion_FU
function basico_crear_site() {
	[[ $1 ]] && SITE="${1}"
	if [[ -z "${SITE}" ]]; then
		if [[ -z "${array_de_valores[0]}" ]]; then
			read -p "SITE NAME → " SITE
		else
			SITE="${array_de_valores[0]}" 
		fi
	fi
	[[ -z "${SITE}" ]] && ohoh $LINENO && echo -e "∅  ${SITE}" && exit
	declare -g SITE="${SITE}"
	set -e
	# 1. Crear el sitio
	hugo new site "${SITE}"
	cd "${SITE}" || exit

	# 2. Inicializar Git y theme
	git init
	git submodule add git@github.com:McShelby/hugo-theme-relearn.git themes/hugo-theme-relearn
	for d in "themes/hugo-theme-relearn" "layouts"; do
		if [[ -d "${d}" ]]; then
			find "${d}" -type f -exec sed -i "s/.Site.IsMultiLingual/hugo.IsMultilingual/g" {} \;
		fi
	done	

	# 3. Crear estructura de contenidos vacía
	mkdir -p content/es
	mkdir -p content/eu

	# 4. Crear mi contenido
	mkdir -p layouts/partials

	cd -
	tmpF="$(mktemp)"
	sed -ne "/^# DIRS/,/^# FIN de VARIABLES 1/p" "${script_auxiliar}" >> "${tmpF}"  
	sed -ne "/^function hugo_FU/,/^# FIN FUNCIONES/p" "${script_auxiliar}" >> "${tmpF}"  
	source "${tmpF}"
	cd "${SITE}"
	crear_plantillas "${SITE}" 
	[[ -f "config.toml" ]] && rm "config.toml"  
	crear_parciales
	rm "${tmpF}"
} # FIN función basico_crear_site
function funcion_main() {
	basico_crear_site "${SITE}" 
	# 5. Lanzar servidor (condicional)
	echo -e "🚀 \033[38;5;208m¿\033[38;5;195mLanzar \033[38;5;155m\033[1mhugo server \033[38;5;208m?\033[0m" 
	if confirmar; then
		hugo server --buildFuture
	fi
} # FIN función funcion_main
# FIN funciónS 2
exit_script() {
	# aquí lo que quiero que se ejecute...
	trap - SIGINT SIGTERM #
	kill -- -$$ # manda SIGTERM a child/sub processess - y a veces la sintaxis es sin el guión que precede al doble dolar
}
trap exit_script SIGINT SIGTERM
# FIN de exit_script
# MAIN
[[ ${FUNCION} == "true" ]] && ${dfuncion} "${array_de_valores[@]}" && exit 
select_funcion_FU
#funcion_main
