#!/bin/bash

# SEC PRELIMS
cuseco=$(basename $0)
array_de_funciones_principales=(
	'hacer_los_directorios_de_las_plantillas'
	'crear_plantillas'
	'crear_parciales'
)	
# FIN de PRELIMS
# DIRS
DIRECTORIOdeTRABAJO="${PWD}"
SRCS_D="${DIRECTORIOdeTRABAJO}/srcs" 
AWK_D="${SRCS_D}/awk" 
FU_D="${SRCS_D}/fu"
# FILES
awkFUS="funciones.awk"
# SEC VARIABLES 1
FUNCION="false" 
AWKCMD="awk -f ${awkFUS}" 
for fuf in $(ls "${FU_D}"/*fu); do
	source "${fuf}"
done	
# FIN de VARIABLES 1
function informacion() {
	echo -e "\033[38;5;11m★ \033[38;5;155m Script que crea los \033[38;5;193marchivos \033[38;5;155mdel \033[38;5;195m\${array_de_valores[\033[38;5;11m0\033[38;5;195m]} \033[3mSITE \033[0m\033[38;5;215mtemplate \033[38;5;208m:
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mconfig.toml
#\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mparams.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mlanguages.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mmenus.es.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mmenus.eu.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14moutputs.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mcascade.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mtaxonomies.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193marchetypes\033[38;5;208m/\033[38;5;14mdefault.md
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdata\033[38;5;208m/\033[38;5;14msettings.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdata\033[38;5;208m/\033[38;5;193mi18n\033[38;5;208m/\033[38;5;14mi18n
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdata\033[38;5;208m/\033[38;5;193mdata\033[38;5;208m/\033[38;5;14mi18n
   	\033[0m"
	if [[ ${#array_de_funciones_principales[@]} -gt 0 ]]; then
		echo -e "\033[38;5;11m★\033[38;5;45m Funciones\033[38;5;218m → "
		for funcion in ${array_de_funciones_principales[@]}
		do
			echo -e " 🔨⚡ \033[38;5;155m${funcion}\033[38;5;218m"
		done | nl
	fi
	echo -e "\033[38;5;218m I job, I job 💕 \033[38;5;228m!!!!"
	return 25
} # FIN de informacion
# SEC GETOPTS
while getopts ":eh" o; do
	case "${o}" in
		e) vim $0 ; exit 0 ;; 
		h) informacion ; exit 0 ;; 
		*) exit 0 ;;
	esac
done
shift $((OPTIND-1))
# FIN de GETOPTS
# SEC VARIABLES 2
array_de_valores=( "$@" )
# FIN de VARIABLES 2
# SECCION FUNCIONES
function select_funcion_FU() {
	select funcion in ${array_de_funciones_principales[@]} "Quit"
	do
		[[ "${funcion}" == "Quit" ]] && break  
		${funcion} ${array_de_valores[@]} 
		break
	done	
} # FIN función select_funcion_FU
function hugo_FU() {
	ARCHES="${1}/archetypes"
	ASSES="${1}/assets"
	CONF="${1}/config"
	CONFDEF="${1}/config/_default"
	CONT="${1}/content"
	CONTES="${1}/content/es"
	CONTEUS="${1}/content/eu"
	DATA="${1}/data"
	DATA18="${1}/data/i18n"
	LAYOUTS="${1}/layouts"
	PARTS="${1}/layouts/partials"
	PUBLIC="${1}/public"
	RESS="${1}/resources"
	RESSASS="${1}/resources/_gen/assets"
	RESSGEN="${1}/resources/_gen"
	RESSIMA="${1}/resources/_gen/images"
	STATIC="${1}/static"
	THEMS="${1}/themes"
} # FIN función hugo_FU
function hacer_los_directorios_de_las_plantillas() {
	DIR="$PWD"
	for t in "config" "archetypes" "data"; do
		ddir="${DIR}/${t}"
		[[ ! -d "${ddir}" ]] && mkdir -p "${DIR}/${t}"
	done
	htdcD="${DIR}/config/_default"
	htarD="${DIR}/archetypes"
	htdaD="${DIR}/data"
	for d in "${htdaD}/i18n" "${htdcD}"; do
		mkdir -p "${d}" 
	done	
} # FIN función hacer_los_directorios_de_las_plantillas
function crear_plantillas() {
	local D_SITE
	[[ ! $1 ]] && ohoh $LINENO && echo -e "∅  \033[38;5;195m\$1" && exit
	D_SITE="${1}"
	hugo_FU "${D_SITE}"
	hacer_los_directorios_de_las_plantillas
	cascade.toml_FU "${D_SITE}"
	config.toml_FU "${D_SITE}"
	default.md_FU "${D_SITE}"
	es.toml_FU "${D_SITE}"
	eu.toml_FU "${D_SITE}"
	languages.toml_FU "${D_SITE}"
	outputs.toml_FU "${D_SITE}"
	params.toml_FU "${D_SITE}"
	settings.toml_FU "${D_SITE}"
	taxonomies.toml_FU "${D_SITE}"
	index.json.json_FU
} # FIN función crear_plantillas
function crear_parciales() {
	create_logohtml_FU 
} # FIN función crear_parciales
# FIN FUNCIONES
exit_script() {
	# aquí lo que quiero que se ejecute...
	trap - SIGINT SIGTERM #
	kill -- -$$
}
trap exit_script SIGINT SIGTERM
# FIN de exit_script
# MAIN
[[ ${FUNCION} == "true" ]] && ${dfuncion} "${array_de_valores[@]}" && exit 
