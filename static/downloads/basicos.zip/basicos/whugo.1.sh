#!/bin/bash

# SEC SOURCES
for fuf in $HOME/bin/functions/*fu; do
	[[ -f ${fuf} ]] && source ${fuf}
done  
source $HOME/.fastcdenvs
# EO SOURCES
# SEC PRELIMS
cuseco=$(basename $0)
allfunkis_special_ARR=(
	'echo_variables_values_FU'
	'cat_d_funki_FU'
	'maketemplatesDirs_FU'
	'create_SITE_TEMPLATES_FU'
	'create_PARTIALS_HTML_FU'
)	
function echo_variables_values_FU() {
	tmpF=$(mktemp)
	${SEDCMD} -ne '/^# DIRS/,/^# FILES/{//!p}' $0 >> ${tmpF}
	${SEDCMD} -ne '/^# FILES/,/^# SEC VARIABLES PRE-GO/{//!p}' $0 >> ${tmpF}
	${SEDCMD} -ne '/^FUNKI=/,/^# EO VARIABLES PRE-GO/{//!p}' $0 >> ${tmpF}
	${SEDCMD} -ne '/^# SEC VARIABLES POST-GO/,/^# EO VARIABLES POST-GO/{//!p}' $0 >> ${tmpF}
	${AWKCMD} -F= '{if (!(match($0,/^#/))){\
		if(match($0,/=/) && !match($0,/\{DOCD\}/)) printf("\033[38;5;14m %15s\033[38;5;208m=\033[38;5;11m%s\n", $1,$2);\
		else{\
			if(match($0,/^declare -a/)){\
				varname=$0;\
				sub(/declare -a /, "",varname);\
				printf("\033[38;5;11m%15s \033[38;5;14m%-20s\n", "declare -a", varname);\
			}else if(match($0,/^declare/)){\
				varname=$0;\
				sub(/declare/, "",varname);\
				printf("\033[38;5;11m%15s \033[38;5;14m%-20s\n", "declare", varname);\
			}else if (!match($0,/\{DOCD\}/)) printf("\033[38;5;14m	%s\n", $0);\
			}}}' ${tmpF}
	rm ${tmpF}
} # EO FUNCTION echo_variables_values_FU
# EO PRELIMS
# DIRS
WDIR="$HOME/pruebas/lanan_HUGO/whugo"
SRCS_D="${WDIR}/srcs" 
AWK_D="${SRCS_D}/${AWKCMD}" 
FU_D="${SRCS_D}/fu"
# FILES
awkFUS="$CFCA/awk_FUNCIONAWKCITAS.awk"
awkF="${AWK_D}/awk_splitinto_functions.awk" 
# SEC VARIABLES PRE-GO
FUNKI="false" 
AWKCMD="${AWKCMD} -f ${awkFUS}" 
for fuf in $(${LSCMD} "${FU_D}"/*fu); do
	source "${fuf}"
done	
# EO VARIABLES PRE-GO
# SEC FUNCTIONS PRE-GO
# EO FUNCTIONS PRE-GO
function whatis() {
	echo_variables_values_FU
	echo -e "\033[38;5;11m★ \033[38;5;155m Script que crea los \033[38;5;193marchivos \033[38;5;155mdel \033[38;5;195m\${dinputARR[\033[38;5;11m0\033[38;5;195m]} \033[3mSITE \033[0m\033[38;5;215mtemplate \033[38;5;208m:
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mconfig.toml
#\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mparams.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mlanguages.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mmenus.es.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mmenus.eu.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14moutputs.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mcascade.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdefault_config\033[38;5;208m/\033[38;5;14mtaxonomies.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193marchetypes\033[38;5;208m/\033[38;5;14mdefault.md
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdata\033[38;5;208m/\033[38;5;14msettings.toml
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdata\033[38;5;208m/\033[38;5;193mi18n\033[38;5;208m/\033[38;5;14mi18n
\033[38;5;11m	→ \033[38;5;14m→ \033[38;5;208m/\033[38;5;193mdata\033[38;5;208m/\033[38;5;193mdata\033[38;5;208m/\033[38;5;14mi18n
   	\033[0m"
	if [[ ${#allfunkis_special_ARR[@]} -gt 0 ]]; then
		echo -e "\033[38;5;11m★\033[38;5;45m Funciones\033[38;5;218m → "
		for funki in ${allfunkis_special_ARR[@]}
		do
			echo -e " 🔨⚡ \033[38;5;155m${funki}\033[38;5;218m"
		done | nl
	fi
	echo -e "\033[38;5;218m I job, I job 💕 \033[38;5;228m!!!!"
	return 25
} # EO whatis
# SEC GETOPTS
while getopts ":ehF:v" o; do
	case "${o}" in
		e) opte ; exit 0 ;; 
		h) whatis ; exit 0 ;; 
		F)
			FUNKI="true" ; isdigit "${OPTARG}"
			[[ ${isdigitRet} -eq 1 ]] && dfn=$(( ${OPTARG}-1 )) && dfunki=${allfunkis_special_ARR[${dfn}]}
			;;
		v) 
			option1="${OPTARG}"
			eval nextopt=\${$OPTIND}
			[[ "${nextopt}" == "-v" ]] && OPTIND=$(( ${OPTIND}+1 )) && eval option2=\${$OPTIND}
			[[ "${option2}" == "-v" ]] && OPTIND=$(( ${OPTIND}+1 )) && eval option3=\${$OPTIND}
			;;
		*) exit 0 ;;
	esac
done
shift $((OPTIND-1))
# EO GETOPTS
# SEC VARIABLES POST-GO
dinputARR=( "$@" )
# EO VARIABLES POST-GO
function select_funki_FU() {
	select funki in ${allfunkis_special_ARR[@]} "Quit"
	do
		[[ "${funki}" == "Quit" ]] && break  
		${funki} ${dinputARR[@]} 
		break
	done	
} # EO FUNCTION select_funki_FU
function cat_d_funki_FU() {
	clear
	echo_variables_values_FU
	echo -e "\033[38;5;11m★ 🐈 \033[38;5;155m CATTING → \033[38;5;45m "
	select funki in "select_funki_FU" "${allfunkis_special_ARR[@]}" "Quit"; do
		[[ "${funki}" == "Quit" ]] && break  
		echo -e "\033[38;5;11m"
		${SEDCMD} -ne "/${funki}()/,/EO FUNCTION ${funki}/p" ${0}
		continua
		echo -e "\033[38;5;11m★\033[38;5;155m CATTING \033[38;5;208m... 🐈 \033[38;5;193m→  "
		REPLY=''
	done
} # EO FUNCTION cat_d_funki_FU
# SEC FUNCTIONS POST-GO
function maketemplatesDirs_FU() {
	DIR="$PWD"
	for t in "config" "archetypes" "data"; do
		ddir="${DIR}/${t}"
		[[ ! -d "${ddir}" ]] && mkdir -p "${DIR}/${t}"
#		echo -e "\033[38;5;11m★\033[38;5;155m ${DIR}/${t}"
	done
	htdcD="${DIR}/config/_default"
	htarD="${DIR}/archetypes"
	htdaD="${DIR}/data"
#	for d in "${htdcD}" "${htarD}" "${htdaD}"; do
#		echo -e "\033[38;5;11m★\033[38;5;155m ${d} \033[38;5;228m"
#		if [[ -d "${d}" ]]; then
#			tree "${d}"
#		else
#			echo -e "\033[38;5;9m ∅  \033[38;5;193m${d}\033[0m"
#		fi
#	done	
	for d in "${htdaD}/i18n" "${htdcD}"; do
#		echo -e "\033[38;5;11m★\033[38;5;155m ${d}"
		mkdir -p "${d}" 
	done	
} # EO FUNCTION maketemplatesDirs_FU
function create_SITE_TEMPLATES_FU() {
	local D_SITE
	[[ ! $1 ]] && ohoh $LINENO && echo -e "∅  \033[38;5;195m\$1" && exit
	D_SITE="${1}"
#set -x
	hugo_FU "${D_SITE}"
#set +x
	maketemplatesDirs_FU
	cascade.toml_FU "${D_SITE}"
	config.toml_FU "${D_SITE}"
	default.md_FU "${D_SITE}"
	es.toml_FU "${D_SITE}"
	eu.toml_FU "${D_SITE}"
	languages.toml_FU "${D_SITE}"
#	menus.es.toml_FU "${D_SITE}" # joined @languages.toml_FU
#	menus.eu.toml_FU "${D_SITE}" # joined @languages.toml_FU
	outputs.toml_FU "${D_SITE}"
	params.toml_FU "${D_SITE}"
	settings.toml_FU "${D_SITE}"
	taxonomies.toml_FU "${D_SITE}"
	index.json.json_FU
} # EO FUNCTION create_SITE_TEMPLATES_FU
function create_PARTIALS_HTML_FU() {
	create_logohtml_FU 
} # EO FUNCTION create_PARTIALS_HTML_FU
# EO FUNCTIONS POST-GO
exit_script() {
	# aquí lo que quiero que se ejecute...
	trap - SIGINT SIGTERM #
	kill -- -$$ # manda SIGTERM a child/sub processess - y a veces la sintaxis es sin el guión que precede al doble dolar
}
trap exit_script SIGINT SIGTERM
# EO exit_script
# MAIN
[[ ${FUNKI} == "true" ]] && ${dfunki} "${dinputARR[@]}" && exit 
#select_funki_FU
#create_SITE_TEMPLATES_FU "${dinputARR[@]}"
