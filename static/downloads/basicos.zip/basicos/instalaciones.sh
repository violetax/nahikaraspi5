#!/usr/bin/env bash
set -e

sudo apt update

sudo apt install -y \
    git \
    neovim \
    curl \
    tree \
    xclip \
    terminator \
    zip \
    unzip

mkdir -p ~/.config/nvim

cat > ~/.config/nvim/init.vim <<'EOF'
set nocompatible

syntax on
filetype plugin indent on

" No capturar el ratón.
set mouse=

" Mostrar números de línea.
set number

" Permitir retroceso "normal".
set backspace=indent,eol,start

" Búsquedas.
set ignorecase
set smartcase
set incsearch

" Indentación.
set autoindent
set tabstop=4
set shiftwidth=4
set expandtab

" Leer .exrc locales de forma segura.
set exrc
set secure
EOF

# Usar Neovim cuando se escriba "vim".
if ! grep -q 'alias vim=nvim' ~/.bashrc 2>/dev/null; then
    echo '' >> ~/.bashrc
    echo '# Use Neovim as Vim' >> ~/.bashrc
    echo 'alias vim=nvim' >> ~/.bashrc
fi

echo
echo -e "Instalación terminada."
echo -e "Abre una nueva terminal o ejecuta:"
echo
echo -e "    source ~/.bashrc"
