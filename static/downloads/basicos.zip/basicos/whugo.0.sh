#!/bin/bash

# SEC SOURCES
for fuf in $HOME/bin/functions/*fu; do
	[[ -f ${fuf} ]] && source ${fuf}
done  
source $HOME/.fastcdenvs
set -Eeuo pipefail
trap 's=$?; echo "Error $s at $BASH_SOURCE:$LINENO: $BASH_COMMAND" >&2' ERR
# EO SOURCES
# SEC PRELIMS
cuseco=$(basename $0)
allfunkis_special_ARR=(
	'echo_variables_values_FU'
	'cat_d_funki_FU'
	'basic_crear_FU'
	'MAIN_FU'
)	
function echo_variables_values_FU() {
	tmpF=$(mktemp)
	${SEDCMD} -ne '/^# DIRS/,/^# FILES/{//!p}' $0 >> ${tmpF}
	${SEDCMD} -ne '/^# FILES/,/^# SEC VARIABLES PRE-GO/{//!p}' $0 >> ${tmpF}
	${SEDCMD} -ne '/^FUNKI=/,/^# EO VARIABLES PRE-GO/{//!p}' $0 >> ${tmpF}
	${SEDCMD} -ne '/^# SEC VARIABLES POST-GO/,/^# EO VARIABLES POST-GO/{//!p}' $0 >> ${tmpF}
	${AWKCMD} -F= '{if (!(match($0,/^#/))){\
		if(match($0,/=/) && !match($0,/\{DOCD\}/)) printf("\033[38;5;14m %15s\033[38;5;208m=\033[38;5;11m%s\n", $1,$2);\
		else{\
			if(match($0,/^declare -a/)){\
				varname=$0;\
				sub(/declare -a /, "",varname);\
				printf("\033[38;5;11m%15s \033[38;5;14m%-20s\n", "declare -a", varname);\
			}else if(match($0,/^declare/)){\
				varname=$0;\
				sub(/declare/, "",varname);\
				printf("\033[38;5;11m%15s \033[38;5;14m%-20s\n", "declare", varname);\
			}else if (!match($0,/\{DOCD\}/)) printf("\033[38;5;14m	%s\n", $0);\
			}}}' ${tmpF}
	rm ${tmpF}
} # EO FUNCTION echo_variables_values_FU
# EO PRELIMS
# DIRS
WDIR="$HOME/pruebas/lanan_HUGO/whugo"
# FILES
templateSH="${WDIR}/whugo.1.sh" 
# SEC VARIABLES PRE-GO
FUNKI="false" 
# EO VARIABLES PRE-GO
# SEC FUNCTIONS PRE-GO
# EO FUNCTIONS PRE-GO
function whatis() {
	echo_variables_values_FU
	echo -e "\033[38;5;11m★ \033[38;5;155m Versión minimalista para \033[38;5;208m:	\033[0m"
	echo -e "\033[38;5;11m◇  1 \033[38;5;195m#\033[38;5;14m Crea el sitio Hugo \033[38;5;195m\${dinputARR[\033[38;5;11m0\033[38;5;195m]}"
	echo -e "\033[38;5;11m◇  2 \033[38;5;195m#\033[38;5;14m Instala el \033[38;5;222mtheme \033[38;5;218mhugo-learn \033[38;5;14mcomo submódulo"
	echo -e "\033[38;5;11m◇  3 \033[38;5;195m#\033[38;5;14m Edita \033[38;5;193mconfig.toml \033[38;5;14mcon lo mínimo necesario para que funcione el theme"
	echo -e "\033[38;5;11m◇  4 \033[38;5;195m#\033[38;5;14m Crea una estructura mínima de contenido con una página de inicio y otra de ejemplo"
	echo -e "\033[38;5;11m◇  5 \033[38;5;195m#\033[38;5;14m Lanza el servidor local, \033[38;5;155mif \033[38;5;195masksure"
	if [[ ${#allfunkis_special_ARR[@]} -gt 0 ]]; then
		echo -e "\033[38;5;11m★\033[38;5;45m Funciones\033[38;5;218m → "
		for funki in ${allfunkis_special_ARR[@]}
		do
			echo -e " 🔨⚡ \033[38;5;155m${funki}\033[38;5;218m"
		done | nl
	fi
	echo -e "\033[38;5;218m I job, I job 💕 \033[38;5;228m!!!!"
	return 0
} # EO whatis
# SEC GETOPTS
while getopts ":ehF:v" o; do
	case "${o}" in
		e) opte ; exit 0 ;; 
		h) whatis ; exit 0 ;; 
		F)
			FUNKI="true" ; isdigit "${OPTARG}"
			[[ ${isdigitRet} -eq 1 ]] && dfn=$(( ${OPTARG}-1 )) && dfunki=${allfunkis_special_ARR[${dfn}]}
			;;
		v) 
			option1="${OPTARG}"
			eval nextopt=\${$OPTIND}
			[[ "${nextopt}" == "-v" ]] && OPTIND=$(( ${OPTIND}+1 )) && eval option2=\${$OPTIND}
			[[ "${option2}" == "-v" ]] && OPTIND=$(( ${OPTIND}+1 )) && eval option3=\${$OPTIND}
			;;
		*) exit 0 ;;
	esac
done
shift $((OPTIND-1))
# EO GETOPTS
# SEC VARIABLES POST-GO
dinputARR=( "$@" )
hugo_FU
[[ $# > 0 ]] && SITE="${dinputARR[0]}"
#source $HOME/.vim/sourceText/hugo_source/hugo_vike
# EO VARIABLES POST-GO
function select_funki_FU() {
	select funki in ${allfunkis_special_ARR[@]} "Quit"
	do
		[[ "${funki}" == "Quit" ]] && break  
		${funki} ${dinputARR[@]} 
		break
	done	
} # EO FUNCTION select_funki_FU
function cat_d_funki_FU() {
	clear
	echo_variables_values_FU
	echo -e "\033[38;5;11m★ 🐈 \033[38;5;155m CATTING → \033[38;5;45m "
	select funki in "select_funki_FU" "${allfunkis_special_ARR[@]}" "Quit"; do
		[[ "${funki}" == "Quit" ]] && break  
		echo -e "\033[38;5;11m"
		${SEDCMD} -ne "/${funki}()/,/EO FUNCTION ${funki}/p" ${0}
		continua
		echo -e "\033[38;5;11m★\033[38;5;155m CATTING \033[38;5;208m... 🐈 \033[38;5;193m→  "
		REPLY=''
	done
} # EO FUNCTION cat_d_funki_FU
# SEC FUNCTIONS POST-GO
function basic_crear_FU() {
	[[ $1 ]] && SITE="${1}"
	if [[ -z "${SITE}" ]]; then
		if [[ -z "${dinputARR[0]}" ]]; then
			read -p "SITE NAME → " SITE
		else
			SITE="${dinputARR[0]}" 
		fi
	fi
#	set -x
	[[ -z "${SITE}" ]] && ohoh $LINENO && echo -e "∅  ${SITE}" && exit
	declare -g SITE="${SITE}"
	set -e
	# 1. Crear el sitio
	hugo new site "${SITE}"
	cd "${SITE}" || exit

	# 2. Inicializar Git y theme
	git init
	git submodule add git@github.com:McShelby/hugo-theme-relearn.git themes/hugo-theme-relearn
	for d in "themes/hugo-theme-relearn" "layouts"; do
		if [[ -d "${d}" ]]; then
			find "${d}" -type f -exec "${SEDCMD}" -i "s/.Site.IsMultiLingual/hugo.IsMultilingual/g" {} \;
		fi
	done	

#	# 3. Crear config/_default/
#	mkdir -p config/_default
#
#	# 4. archetypes/default.md
#	mkdir -p archetypes
#
#	# 5. Crear data/
#	mkdir -p data/i18n
#
	# 6. Crear estructura de contenidos vacía
	mkdir -p content/es
	mkdir -p content/eu

	# 7. Crear mi contenido
	mkdir -p layouts/partials

	tmpF="$(mktemp)"
	"${SEDCMD}" -ne "/^# DIRS/,/^# EO VARIABLES PRE-GO/p" "${templateSH}" >> "${tmpF}"  
	"${SEDCMD}" -ne "/^# SEC FUNCTIONS POST-GO/,/^# EO FUNCTIONS POST-GO/p" "${templateSH}" >> "${tmpF}"  
	source "${tmpF}"
	create_SITE_TEMPLATES_FU "${SITE}" 
	[[ -f "config.toml" ]] && rm "config.toml"  
	create_PARTIALS_HTML_FU
	rm "${tmpF}"
} # EO FUNCTION basic_crear_FU
function MAIN_FU() {
#	set -x
	basic_crear_FU "${SITE}" 
	# 7. Lanzar servidor (condicional)
	echo -e "🚀 \033[38;5;195mLaunch \033[38;5;155m\033[1mhugo server --buildFuture \033[38;5;208m??? \033[38;5;43m( \033[38;5;195m--buildDrafts \033[38;5;9mnot \033[38;5;195mincluded \033[38;5;43m)\033[0m"
	if asksure; then
		hugo server --buildFuture
	fi
} # EO FUNCTION MAIN_FU
# EO FUNCTIONS POST-GO
exit_script() {
	# aquí lo que quiero que se ejecute...
	trap - SIGINT SIGTERM #
	kill -- -$$ # manda SIGTERM a child/sub processess - y a veces la sintaxis es sin el guión que precede al doble dolar
}
trap exit_script SIGINT SIGTERM
# EO exit_script
# MAIN
[[ ${FUNKI} == "true" ]] && ${dfunki} "${dinputARR[@]}" && exit 
select_funki_FU
#MAIN_FU
