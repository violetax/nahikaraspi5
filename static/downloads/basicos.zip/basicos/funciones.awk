function basename(path,  i, parts) {
    i = split(path,  parts, "/")
    return parts[i]
}
function untilde(line) {
	gsub(/á/,"a",line)
	gsub(/é/,"e",line)
	gsub(/í/,"i",line)
	gsub(/ó/,"o",line)
	gsub(/ú/,"u",line)
	gsub(/Á/,"A",line)
	gsub(/É/,"E",line)
	gsub(/Í/,"I",line)
	gsub(/Ó/,"O",line)
	gsub(/Ú/,"U",line)
	return line
}
function underjoin(line) {
	gsub(/ /,"_",line)
	return line
}
function detectOS(	cmd, os) {
	cmd = "uname -s"
	cmd | getline os
	close(cmd)
	return os
}
function PRIMELETTER(line) {
	match(line, /^./)
	p = substr(line, RSTART, RLENGTH)
	return p
}
function extractCcommenttext(line) {
	if (/^\/\*/) {
		sub(/.*\/\*/, "",line)
		sub(/\*\/.*/, "",line)
		gsub(/^[ \t]+|[ \t]+$/, "", line)
		gsub(/ /, "_", line)
		gsub(/[^[:alnum:]_]/, "", line)
		gsub(/__/, "_", line)
		gsub(/ /, "", line)
		if (length) return line;
	}
}
function content__init__py_file(line,   funame)
{
	if (line ~ /^def /) {
		match($0,/\(/)
		funame = substr($0, 5, RSTART - 5)
		match(FILENAME,/\.py/)
		FINAME = substr(FILENAME, 0, RSTART - 1)
		printf("\"%s\":  (\"%s\", \"%s\"),\n", funame, FINAME, funame)
	}
}
function procesa_fichero_aparte(headfile, file,   weight)
{
     while ((getline line < headfile) > 0) {
		 if (line ~ /^title/) {
			 line = substr(line, 1, length(line) - 1) " " weight "\""
		 }
         print line > file
		 if (line ~ /^date/) print "weight: " w > file
     }
     close(headfile)
}
# Y después, por ejemplo:
# {
#	if ($0 ~ /^# VIO/) {
#		close(filename)
#		filename = "slide" w++ ".md"
#		procesa_fichero_aparte(head, filename, w)
#		print $0 > filename # hace falta para printar esta misma línea, por el next
#		next ← importante
#	}
#	{
#		print $0 > filename ... # continuar en otro statement
#	}
#
# SOBRE SUSTITUCIONES: 
#	└─ ÚLTIMO CHAR: 
#		└─ $0 = substr($0, 1, length($0) - 1) " " variable " resto de string\"" 
#			└─ ↑ eso sustituye el último char (por ejemplo unas ") por ' $variable resto de string"'
